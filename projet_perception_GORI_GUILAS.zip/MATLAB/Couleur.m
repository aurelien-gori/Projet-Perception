function [BW,maskedRGBImage] = Couleur(RGB)

%------------------------------------------------------------------------
% R�cup�ration de l'image
%------------------------------------------------------------------------

I = RGB;

%------------------------------------------------------------------------
% On d�finit un intervalle qu'on va utiliser pour chaque couleur, jusqu'�
% d�tecter les bonnes nuances de jaune
%------------------------------------------------------------------------

% Rouge
R1 = 42498.000;
R2 = 65535.000;

% Vert
V1 = 48295.000;
V2 = 65535.000;

% Bleu
B1 = 771.000;
B2 = 40494.000;

%------------------------------------------------------------------------
% On cr�e un masque � partir des intervalles trouv�s
%------------------------------------------------------------------------

BW = (I(:,:,1) >= R1 ) & (I(:,:,1) <= R2) & ...
    (I(:,:,2) >= V1 ) & (I(:,:,2) <= V2) & ...
    (I(:,:,3) >= B1 ) & (I(:,:,3) <= B2);
BW2 = BW;

%------------------------------------------------------------------------
% On r�cup�re l'image dans une autre variable
%------------------------------------------------------------------------

maskedRGBImage = RGB;

%------------------------------------------------------------------------
% On utilise le masque BW2 afin d'enlever toutes les couleurs se situant
% dans les zones noires du masque (BW2). Ainsi, il ne nous reste plus que
% les bou�es sur l'image retourn�e
%------------------------------------------------------------------------

maskedRGBImage(repmat(~BW2,[1 1 3])) = 0;
end
