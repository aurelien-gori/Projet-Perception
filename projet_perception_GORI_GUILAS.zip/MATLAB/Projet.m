%-----------------------------------------------------------------------
% Polytech Montpellier
% Projet r�alis� par GORI Aur�lien & GUILAS Dan
% 2019-2020, Semestre 7
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
% On r�cup�re la vid�o
%-----------------------------------------------------------------------

vid=VideoReader('resume.mp4');
vid.CurrentTime = 0.0;
currAxes = axes;
while hasFrame(vid)
    RGB = readFrame(vid);
    image(RGB, 'Parent', currAxes)
    currAxes.Visible = 'off';
    
%-----------------------------------------------------------------------
% On appelle les fonctions cr��es afin d'obtenir deux masques :
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
% Couleur("image"), d�tecte le jaune dans l'image
% Ombre("image"), d�tecte les diff�rentes nuances de jaune dans l'image
%-----------------------------------------------------------------------

    % On cr�e le masque RGB
    MasqueCouleur = Couleur(RGB);

    % On cr�e un masque HSV
    MasqueOmbre = Ombre(RGB);
    MasqueOmbre = cast(MasqueOmbre, 'logical');
    MasqueOmbre = bwareaopen(MasqueOmbre, 500);

    % On cr�e le masque final
    Masque = MasqueCouleur | MasqueOmbre;
    MasqueFinal = bwareaopen(Masque, 18); % On enl�ve le bruit

%-----------------------------------------------------------------------
% Cr�ation des variables n�cessaires � l'encadrage des bou�es
%-----------------------------------------------------------------------

    stats = regionprops(MasqueFinal, 'BoundingBox', 'Centroid', 'Extrema');
    bb_memory = zeros(length(stats),4);
    ex_memory = zeros(length(stats),2,2);
    angle = zeros(length(stats),1);

%-----------------------------------------------------------------------
% Appel de la fonction BBRectangle qui encadre les bou�es
%-----------------------------------------------------------------------

    [img] = BBRectangle(stats, bb_memory, ex_memory, angle);
    pause(1/vid.Framerate);
end
