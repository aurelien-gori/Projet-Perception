function img = BBRectangle(stats, bb_memory, ex_memory, angle)

hold on
for object = 1:length(stats)
    bb = stats(object).BoundingBox;
    bb_memory(object,:) = bb;
    
    ex = stats(object).Extrema;
    ex_memory(object,1,1) = ex(2,1);
    ex_memory(object,1,2) = ex(2,2);
    ex_memory(object,2,1) = ex(4,1);
    ex_memory(object,2,2) = ex(4,2);
end
hold off

%-----------------------------------------------------------------------
% On traite les diff�rents cas d'encadrage
%-----------------------------------------------------------------------

% Quand on a 4 objets d�tect�s sur l'image
if(length(stats) == 4 || length(stats) == 3)
    object_marked = 0; % Variable qui passe � 1 s'il y a collision des bounding box
    for i = 1:length(stats)-1
        % On cr�e des conditions pour d�finir chaque cas de d�tection
        % (expliqu� dans le compte-rendu)
        CH2 = (bb_memory(i,1)-bb_memory(i+1,1) < 285)&&(bb_memory(i,1)-bb_memory(i+1,1)> 0); %On prend le X de la boundingbox i+1

        CH1 = (bb_memory(i+1,1)-bb_memory(i,1) < 285)&&(bb_memory(i+1,1)-bb_memory(i,1) > 0); %On prend le X de la boundingbox i

        CV2 = (bb_memory(i,2)-bb_memory(i+1,2) < 400)&&(bb_memory(i,2)-bb_memory(i+1,2) > 0); %On prend le Y de la boundingbox i+1

        CV1 = (bb_memory(i+1,2)-bb_memory(i,2) < 400)&&(bb_memory(i+1,2)-bb_memory(i,2) > 0); %On prend le Y de la boundingbox i

        if(CH2 && CV2)
            A = [bb_memory(i+1,1)...
                 bb_memory(i+1,2)...
                 bb_memory(i,1)-bb_memory(i+1,1)+bb_memory(i,3)...
                 bb_memory(i,2)-bb_memory(i+1,2)+bb_memory(i,4)];
             object_marked = 1;
             angle(i,1) = getOrientation(ex_memory(i,1,1), ex_memory(i,1,2), ex_memory(i,2,1), ex_memory(i,2,2));
        elseif(CH2 && CV1)
            A = [bb_memory(i+1,1)...
                 bb_memory(i,2)...
                 bb_memory(i,1)-bb_memory(i+1,1)+bb_memory(i,3)...
                 bb_memory(i+1,2)-bb_memory(i,2)+bb_memory(i+1,4)];
             object_marked = 1;
             angle(i,1) = getOrientation(ex_memory(i,1,1), ex_memory(i,1,2), ex_memory(i,2,1), ex_memory(i,2,2));
        elseif(CH1 && CV2)
            A = [bb_memory(i,1)...
                 bb_memory(i,2)...
                 bb_memory(i+1,1)-bb_memory(i,1)+bb_memory(i+1,3)...
                 bb_memory(i,2)-bb_memory(i+1,2)+bb_memory(i,4)];
             object_marked = 1;
             angle(i,1) = getOrientation(ex_memory(i,1,1), ex_memory(i,1,2), ex_memory(i,2,1), ex_memory(i,2,2));
        elseif(CH1 && CV1)
            A = [bb_memory(i,1)...
                 bb_memory(i,2)...
                 bb_memory(i+1,1)-bb_memory(i,1)+bb_memory(i+1,3)...
                 bb_memory(i+1,2)-bb_memory(i,2)+bb_memory(i+1,4)];
             object_marked = 1;
             angle(i,1) = getOrientation(ex_memory(i,1,1), ex_memory(i,1,2), ex_memory(i,2,1), ex_memory(i,2,2));
        else
            if(object_marked == 0)
            A = [bb_memory(i,1)...
                 bb_memory(i,2)...
                 bb_memory(i,3)...
                 bb_memory(i,4)];
            angle(i,1) = getOrientation(ex_memory(i,1,1), ex_memory(i,1,2), ex_memory(i,2,1), ex_memory(i,2,2));
            object_marked = 0;
            end
        end
        
        if(angle(i,1) > 90)
            angle(i,1) = -(angle(i,1)-135);
        else
            % Do nothing
        end
        A1 = expand(A);
        rectangle('Position',A1,'EdgeColor','r','LineWidth',2)
        if(angle(i,1) ~= 0)
            a = sprintf('Angle : %g�', angle(i,1));
            text(A(1)+A1(3)/2,A1(2)-37,a,'color','b','HorizontalAlignment','center')
        end
    end
end
if (length(stats) == 2)
    for i = 1:length(stats)
        bb = stats(i).BoundingBox;
        angle(i,1) = getOrientation(ex_memory(i,1,1), ex_memory(i,1,2), ex_memory(i,2,1), ex_memory(i,2,2));
        if(angle(i,1) > 90)
            angle(i,1) = -(angle(i,1)-135);
        else
            % Do nothing
        end
        bb1 = expand(bb);
        rectangle('Position',bb1,'EdgeColor','r','LineWidth',2)
        if(angle(i,1) ~= 0)
            a = sprintf('Angle :  %g�', angle(i,1));
            text(bb1(1)+bb1(3)/2,bb1(2)-37,a,'color','b','HorizontalAlignment','center')
            
        end
    end
end
if (length(stats) == 1)
    angle(:,1) = getOrientation(ex(1,1), ex(1,2), ex(5,1), ex(5,2));
    if(angle(:,1) > 90)
        angle(:,1) = -(angle(:,1)-135);
    else
        % Do nothing
    end
    bb1 = expand(bb);
    rectangle('Position',bb1,'EdgeColor','r','LineWidth',2)
    if(angle(1,1) ~= 0)
        a = sprintf('Angle : %g�', angle(1,1));
        text(bb1(1)+bb1(3)/2,bb1(2)-37,a,'color','b','HorizontalAlignment','center')
    end
end
img = 1;
end

function new = expand(A)
    new(1) = A(1) - 20;
    new(2) = A(2) - 20;
    new(3) = A(3) + 40;
    new(4) = A(4) + 40;
end