function angle = getOrientation(TLx, TLy, BRx, BRy)
pente = (TLy-BRy)/(TLx-BRx);
p1 = pente; % coordonn�e y du point pour b = 0 et x = 1
angle = round(acos(p1/(sqrt(p1^2+1)))*(180/pi),0); % L'angle est pas ouf � revoir
end